package pe.edu.idat.DSWevaluacion1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dsw1Ec1L11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
